/*
 * Universidad Estatal a Distancia
Estudiante:Melissa Guadamuz Fernández
Cedula:113870559
Centro Universitario San José
Grupo # 1
Tutor JOSE MANUEL SALAZAR HERRERA
Tarea#1
Primer Cuatrimestre 2022
 */
import Vista.ExportaCR;

/**
 *
 * @author melig
 */
public class main {
    
    public static void main(String args[]) {
        ExportaCR v = new ExportaCR();
        v.setVisible(true);
    }
    
}
