/*
 * Universidad Estatal a Distancia
Estudiante:Melissa Guadamuz Fernández
Cedula:113870559
Centro Universitario San José
Grupo # 1
Tutor JOSE MANUEL SALAZAR HERRERA
Tarea#1
Primer Cuatrimestre 2022
 */
package Modelo;

/**
 *
 * @author melig
 */
public class CargaPesada extends Cotizacion {
    private String tipoCarga;
    private boolean piesContenedor;
    
    /*
    CalcularExportacion: Este cálculo se genera según lo siguiente:
        • Un contenedor 40 pies vacío tiene un peso o tara de 3.750 kg y
        admite una carga de alrededor de 29 toneladas (29.000 kg), lo
        cual los primeros 3.750 kg se cobraran a $20 dólares, y a partir
        del kilo 3751 se cobrara a $ 75 dólares. Servicio exclusivo por
        barco.
        • Un contenedor 20 pies vacío tiene un peso o tara de 1.500 kg y
        admite una carga de alrededor de 28 toneladas (28.000 kg), lo
        cual los primeros 1500 kg se cobraran a $20 dólares, y a partir
        del kilo 1501 se cobrara a $ 85 dólares. Servicio exclusivo por
        barco.
        • La carga embalada se cobrara por Kilo en barco a $ 75 dólares o
        en avión $125 el kilo. Esta modalidad es la única que permite a
        nivel de carga pesada escoger si se envía por avión o por barco.
        • Los contenedores no pueden superar las cargas máximas
        indicadas.
    */
}
